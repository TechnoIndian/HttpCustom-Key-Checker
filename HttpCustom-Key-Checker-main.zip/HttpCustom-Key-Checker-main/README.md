# Http-Custom-Keytime 
             🛕🛕🛕🛕
🚩🚩Jai Shree Ram 🚩🚩
             🛕🛕🛕🛕

~~🇮🇳 𓃮 ꧁ T̴͢͢e̴͢͢c̴͢͢h̴͢͢n̴͢͢o̴͢͢ ☣ I̴͢͢n̴͢͢d̴͢͢i̴͢͢a̴͢͢ ꧂ 𓃮 🇮🇳~~

🙏🏻🙏🏻 🇮🇳 W̊e̊l̊c̊o̊m̊e̊ b̊ẙ T̊e̊c̊h̊n̊o̊ I̊n̊d̊i̊å 🇮🇳 🙏🏻🙏🏻

☯︎BOT~ @Httpcustomkey_bot
☯︎ Telegram GROUP~ @rktechnoindian

# Installation 

∆ HOW TO CHECK KEY VELEDITY ∆

SCRIPT INSTALLATION COMMAND:-

$ pkg update

$ pkg upgrade

$ pkg install git

$ pkg install jq

$ pkg install python

$ git clone https://github.com/TechnoIndian/HttpCustom-Key-Checker

$ ls

$ cd HttpCustom-Key-Checker

$ ls

$ chmod +x keytime.sh

$ ./keytime.sh

Enter Your Key & Enjoy

SHERE WITH CREDIT...🙏

CREDIT:- @rktechnoindian

THANQ...❤️


# Credit:- https://t.me/rktechnoindian
